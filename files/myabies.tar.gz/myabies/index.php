<?php
////////////////////////////
//
//	 MyAbies: index.php (pagina principal)
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
////////////////////////////

ob_start();
session_start();

//Evitamos la salida de errores al usuario
error_reporting(0);

//comprobacion de ficheros de configuracion
if (!file_exists("content/data/adm.php") OR !file_exists("content/data/db.php"))
{
	//si falta alguno de los ficheros, redirigimos a la zona de administración
	header("Refresh:0;'admin.php'");
}

//compruebo si se solicita reinicio
include_once "includes/funciones.php";
if( isset( $_REQUEST['reinicio'] ) AND ($_REQUEST['reinicio']=="1" ))
{
	reinicio();
}
//////////////////////////////////////
// Carga de ficheros
//////////////////////////////////////
// Ruta, resultados por pagina y array provincias
include_once "content/config.php";


//////////////////////////////////////
// Generacion de la página
//////////////////////////////////////


//comienzo de la web, con encabezados.
include_once "content/encabezadocss.php";

//genera los datos del centro (si los hay) y comienza la pagina
include_once "content/estatico.php";
beginAbies();

//comprobamos si hay consulta y mostramos resultados

include_once "content/mostrar.php";


//
//	Por último mostramos el formulario de búsquedas
//
include_once "content/formulario.php";
formularioAbies();

//cerramos la pagina
endAbies();

//terminamos
exit;
?>

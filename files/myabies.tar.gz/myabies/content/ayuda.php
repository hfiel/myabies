<?php
////////////////////////////
//
//	 MyAbies: ayuda.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//
////////////////////////////
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es-es">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" /><title>Ayuda de MyAbies</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<h2>
		<span style="font-weight: bold;">Ayuda de MyAbies</span>
	</h2>
	<hr/>
	Para llevar a cabo las búsquedas introduce los términos de consulta en las casillas correspondientes, y pulsa el botón aceptar. 
	<ol>
		<li>Búsquedas por autor, título, editorial: pon el nombre o parte del mismo. Los autores se almacenan como <em>apellido apellido, nombre</em>. Si buscas <em>Miguel de Cervantes Saavedra</em> no obtendrás ninguna respuesta, deberás buscar <em>Cervantes Saavedra, Miguel de</em>. Para obtener los mejores resultados, se recomienda poner una única palabra por cada campo.
		</li>
		<li>Búsquedas por ISBN: introduce el ISBN del ejemplar a buscar. 
		</li>
		<li>Búsquedas por depósito legal, código del ejemplar o signatura: puedes buscar un documento concreto (con todo el código) o llevar a cabo una búsqueda parcial (dando sólo parte del código).
			<ol>
			<li> El primer campo de la signatura corresponde a la clasificación <a href="http://es.wikipedia.org/wiki/Clasificaci%C3%B3n_Decimal_Universal">CDU</a>. Una <a href="http://www.mcu.es/libro/docs/TablaCDU.pdf">lista de la clasificación</a> se puede encontrar en la Web de la <a href="http://www.mcu.es/libro/CE/AgenciaISBN/InfGeneral/TablaCDU.html">Agencia Española del ISBN</a>.
			</ol>
		</li>
		<li>Tipo de documento: selecciona el formato del documento a buscar (libro, revista, etc.). De forma predeterminada se buscan todos los documentos. Ten en cuenta que muchos centros sólo tienen catalogados libros. 
		</li>
	</ol>
	Por ejemplo, para buscar ejemplares de <em>Don Quijote de la Mancha</em> de <em>Miguel de Cervantes Saavedra</em> editados en <em>Madrid</em>, puedes poner <em>cervantes</em> en la casilla de autor, <em>quijote</em> en la casilla de título y seleccionar <em>M</em> en la lista de provincia del depósito legal.<br/>
	<hr>
	Al aparecer los resultados, el panel de búsqueda y la barra superior se ocultan. Puedes hacerlos visibles pulsando <em>Mostrar formulario de búsqueda</em> o <em>Mostrar la barra superior</em> respectivamente.<br/> 
	Si se obtienen más de 10 resultados, se mostrarán separados en páginas. Podrás moverte por las páginas siguiendo los enlaces que aparecen sobre la tabla de resultados.<br/>
	Se puede ordenar los resultados por Título o Autor, en orden ascendente o descendente. Para cambiar el orden, hay que hacer clic en el nombre de la columna deseada (título o autor).<br/>
	<hr/>
	Para limpiar los resultados y reiniciar la búsqueda, puedes hacer una búsqueda con nuevos datos, o seguir el enlace <em>Inicio</em> en la parte superior de la página.
	<br/>
	Si deseas limpiar el formulario de búsqueda sin perder los resultados que ya tienes, pulsa el botón <em>Limpiar todo</em>.
	<hr/>
	Puedes obtener más datos de un resultado concreto haciendo clic en <img src="../img/librarian.gif" />, en la columna <em>detalles</em> correspondiente.<br/>
	Para volver a la consulta original con todos los resultados, haz clic en <img src="../img/volverconsulta.png" width="30" heigth="30"/> bajo la tabla con los resultados.<br/>
	También puedes consultar otros libros sobre un autor concreto, haciendo clic en <img src="../img/masautor.gif" /> en la lista de resultados.
	<hr/>
</body>
</html>
<?php
////////////////////////////
//
//	 MyAbies: mostrar.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
// procesa las peticiones, crea las consultas de busqueda 
// y muestra los resultados en su caso
//////////////////////////



//lee los valores que se han pasado por POST O GET (si los hay),
//y los limpia, almacenando en un array

$arrPost=array();
$arrPost=cargaPost();
//
//	Si se solicitan detalles de un resultado en concreto
//  lo mostramos y nos salimos. Es un caso excepcional.
//
if( isset( $arrPost['idFondo'] ) && $arrPost['idFondo']!=0 )
{
    $cTexto = "";
	//generamos la consulta
    $cSql = "SELECT * FROM fondos LEFT JOIN autores on fondos.IdAutor=autores.IdAutor LEFT JOIN editoriales on fondos.idEditorial=editoriales.IdEditorial LEFT JOIN tiposfondo on fondos.idTipoFondo=tiposfondo.IdTipoFondo WHERE idfondo = $arrPost[idFondo]";
	//mostramos los datos basicos del resultado, sin texto
    echo "<div id=\"resultados\">\n";
    listadoFondos( $cTexto, $cSql );	
	//mostramos los detalles del fondo
    fichaFondo( $arrPost['idFondo'] );
    echo "</div>\n";
	//ponemos el formulario de consulta
	include_once "content/formulario.php";
	formularioAbies();
	//cerramos la pagina
	endAbies();
	//terminamos
	exit;
}



//
//	Si no hay fondo, recorremos los campos del formulario para ver si contienen algo y
//  en su caso generamos las cadenas con la consulta de busqueda,
//  que se almacenan en las session:
//		$_SESSION['cSql']
//		$_SESSION['cTexto']
// 
// Primero preparamos las SESSION de paginación y ordenacion
// luego preparamos la SESSION de busqueda
// y mostramos los resultados


//preparacion de las session de paginacion y ordenacion
include_once "content/orden.php";


// proceso $arrPost y genero las session con las cadenas SQL
include_once "content/buscar.php";
busqueda();

//Si hay consultas, mostramos los resultados, con la ordenación y la paginacion.
if( isset($_SESSION['cSql']) OR isset($_SESSION['cTexto']))
{
	echo "<div id=\"resultados\">\n";
	listadoFondos( $_SESSION['cTexto'], $_SESSION['cSql'], $_SESSION['orden'], $_SESSION['direc'], $_SESSION['pagina'] );
	echo "</div>\n";
}


?>
<?php
////////////////////////////
//
//	 MyAbies: buscar.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//
//
// busqueda -> Procesa las peticiones y prepara la consulta de busqueda
// almacenando las cadenas en session
//
///////////////////////////////////


function busqueda()
{
 global $arrPost;
	
	$busquedaExacta = "%";	// caracter comodin para las busquedas en mysql, permite hacer busquedas no exactas
	$hayDatos="0";


	$cTexto = "";
	$cSql = "";
	
	//para generar la cadena de signatura a mostrar en pantalla
	$cSig = "";
	
	//para saber si ya he entrado en mas campos antes
	// y tengo que añadir un and	
	$comp=0; 


// busqueda por campos
// se van rellenando las cadenas de consulta
// y se lanza al final
	
	//tipofondo
	if( isset( $arrPost['tipofondo'] ) && $arrPost['tipofondo'] )
	{
		$cTexto .= sprintf( "Tipo de Fondo = %s; ", $arrPost['tipofondo'] );
		$cSql .= sprintf( "tipofondo like '%s%s%s'", $busquedaExacta, $arrPost['tipofondo'], $busquedaExacta );
		$comp=1;
	}

	//autor
	if( isset( $arrPost['autor'] ) && $arrPost['autor'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "Autor = %s; ", $arrPost['autor'] );
		$cSql .= sprintf( "a like '%s%s%s'", $busquedaExacta, $arrPost['autor'], $busquedaExacta );
		$comp=1;
	}

	//por ISBN
	if( isset( $arrPost['isbn'] ) && $arrPost['isbn'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "ISBN = %s; ", $arrPost['isbn'] );
		$cSql .= sprintf( "(fondos.ISBN like '%%%s%%' OR fondos.ISBN2 like '%%%s%%')", $arrPost['isbn'],$arrPost['isbn'] );
		$comp=1;
	}
	
	//por deposito legal:
	if( (isset( $arrPost['dl_provincia'] ) && $arrPost['dl_provincia'] ) or (isset( $arrPost['dl_codigo'] ) && $arrPost['dl_codigo'] ) or (isset( $arrPost['dl_ano'] ) && $arrPost['dl_ano'] ))
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "DL = %s-%s-%s; ", $arrPost['dl_provincia'], $arrPost['dl_codigo'], $arrPost['dl_ano'] );

		$parcialdl="";
		if (isset( $arrPost['dl_provincia'] ))
		{
			$parcialdl = "%" . $arrPost['dl_provincia'] ."%";
		}
		if (isset( $arrPost['dl_codigo'] ))
		{
			if ($parcialdl!="")
			{
				$parcialdl=substr($parcialdl, 0, -1);
			}
			$parcialdl .= "%" . $arrPost['dl_codigo'] ."%";
		}
		if (isset( $arrPost['dl_ano'] ))
		{
			if ($parcialdl!="")
			{
				$parcialdl=substr($parcialdl, 0, -1);
			}
			$parcialdl .= "%" . $arrPost['dl_ano'] ."%";
		}		
		$cSql .= sprintf( "depositolegal like '%s'", $parcialdl );

		$comp=1;
	}



	//IdAutor
	if( isset( $arrPost['IdAutor'] ) && $arrPost['IdAutor'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= "Otros resultados del mismo autor";
		$cSql .= sprintf( "fondos.IdAutor like '%s'", $arrPost['IdAutor'] );
		$comp=1;
	}

	//titulo
	if( isset( $arrPost['titulo'] ) && $arrPost['titulo'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "Título = %s; ", $arrPost['titulo'] );
		$cSql .= sprintf( "titulo like '%s%s%s'", $busquedaExacta, $arrPost['titulo'], $busquedaExacta );
		$comp=1;
	}

	//editorial
	if( isset( $arrPost['editorial'] ) && $arrPost['editorial'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "Editorial = %s; ", $arrPost['editorial'] );
		$cSql .= sprintf( "editorial like '%s%s%s'", $busquedaExacta, $arrPost['editorial'], $busquedaExacta );
		$comp=1;
	}

	//coleccion
	if( isset( $arrPost['coleccion'] ) && $arrPost['coleccion'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "Coleccion = %s; ", $arrPost['coleccion'] );
		$cSql .= sprintf( "serie like '%s%s%s'", $busquedaExacta, $arrPost['coleccion'], $busquedaExacta );
		$comp=1;
	}

	//codigo ejemplar
	if( isset( $arrPost['codejemplar'] ) && $arrPost['codejemplar'] )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cTexto .= sprintf( "Codigo Ejemplar = %s; ", $arrPost['codejemplar'] );
		$cSql .= sprintf( "CodigoEjemplar like '%s%s%s'", $busquedaExacta, $arrPost['codejemplar'], $busquedaExacta );
		$comp=1;
	}

	//campo 1 signatura
	if( (isset( $arrPost['signatura1'] ) && $arrPost['signatura1']) )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cSig .= sprintf( "%s", $arrPost['signatura1']);
		$cSql .= sprintf( "sig1 like '%s%s%s' ", $busquedaExacta, $arrPost['signatura1'], $busquedaExacta);
		$comp=1;
	}

	//campo 2 signatura
	if( (isset( $arrPost['signatura2'] ) && $arrPost['signatura2']) )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cSig .= sprintf( " %s", $arrPost['signatura2']);
		$cSql .= sprintf( "sig2 like '%s%s%s' ", $busquedaExacta, $arrPost['signatura2'], $busquedaExacta);
		$comp=1;
	}

	//campo 3 signatura
	if( (isset( $arrPost['signatura3'] ) && $arrPost['signatura3']) )
	{
		if ($comp!=0)
		{
			$cSql .= " and ";
		}
		$cSig .= sprintf( " %s", $arrPost['signatura3']);
		$cSql .= sprintf( "sig3 like '%s%s%s' ", $busquedaExacta, $arrPost['signatura3'], $busquedaExacta);
		$comp=1;
	}
	


	//si tenemos texto para pantalla (y por lo tanto consulta) o signatura
	if( $cTexto OR $cSig)
	{
		//si hay signatura, la añado al texto en pantalla ya completa
		if ($cSig)
		{
			$cTexto.=sprintf( "Signatura = %s ", $cSig);
		}

		// cadena que contiene las tablas y join para hacer las consultas
		$tablas ="fondos LEFT JOIN tiposfondo ON tiposfondo.IdTipoFondo = fondos.IdTipoFondo LEFT JOIN autores ON autores.IdAutor = fondos.IdAutor LEFT JOIN editoriales ON editoriales.IdEditorial = fondos.IdEditorial LEFT JOIN ejemplares ON ejemplares.IdFondo=fondos.IdFondo ";
		
		//genero la consulta con todos los campos
		//mediante las variables tablas y cSql, y pongo el orden adecuado según las session
		$cSql = sprintf( "SELECT DISTINCT fondos.IdFondo, Titulo, a, autores.IdAutor  FROM %s WHERE %s", $tablas, $cSql);
	  
		//establece las cadenas de busqueda y texto en las session
		$_SESSION['cSql']=$cSql;
		$_SESSION['cTexto']=$cTexto;
	}
}
?>
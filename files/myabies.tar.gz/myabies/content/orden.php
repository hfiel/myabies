<?php
////////////////////////////
//
//	 MyAbies: orden.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//
// Comprobaciones y establecimiento de SESSION 
// para gestionar la paginacion y ordenacion de resultados
//
//
//////////////

//primero compruebo si he recibido paginación por GET, la limpio y almaceno en session.
if( isset($_GET['p']))
{
	$_SESSION['pagina']=preg_replace("/[^0-9]/","",ioCleanEstricta($_GET['p']));
}
else //si no he recibido y no tenía almacenada, la pongo a 1
{
	if (!isset($_SESSION['pagina']))
	{
		$_SESSION['pagina']="1";
	}
}

//ahora compruebo si tengo ordenación:

//si no he recibido orden, compruebo si ya tenia almacenado uno, y ordeno por titulo en direccion ascendente
if (!(isset($_GET['orden'])) OR $_GET['orden']=="")
{
	if (!isset($_SESSION['orden'])) //no tengo orden almacenado, pongo predeterminado
	{
		$_SESSION['orden']="titulo";
		$_SESSION['direc']="ASC";
	}
}
else  //si recibo orden, compruebo si el mismo de antes (para cambiar la direccion) o si es nuevo (predeterminado en ASC)
{
	//limpio el valor recibido en temporal
	$ordenTmp=ioCleanEstricta($_GET['orden']);
	
	if ($_SESSION['orden']==$ordenTmp) //si es el mismo orden, invierto direccion
	{
		
		if ($_SESSION['direc']=="ASC") //era ascendente, pongo direccion descendente
		{
			$_SESSION['direc']="DESC";
		}
		else //era descendente, pongo ascendente
		{
			$_SESSION['direc']="ASC";
		}
		
	}
	else //el orden es distinto, lo pongo en asc
	{
		//aqui faltaría comprobar que el orden recibido corresponde a una de las tablas empleadas en la consulta
		//por ahora lo pongo pensando solo en titulo y autor
		$_SESSION['orden']=$ordenTmp;
		$_SESSION['direc']="ASC";
	}  	
}
?>
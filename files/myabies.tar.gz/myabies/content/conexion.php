<?php
////////////////////////////
//
//	 MyAbies: conexion.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
// Funciones de conexion a la BBDD
//
////////////////////////////


//conexion a MySQL
function conectaDb()
{
	include_once "data/db.php";
	if (!defined("DB_TYPE")) //si no tengo definida esa constante, es que la carga del fichero a fallado o los datos son erroneos
	{
		die("Error al cargar la configuracion de la base de datos. Contacte con el administrador (Error 007)\n");
	}
	//conexion a la BBDD, si no puede termina
	$idCon = mysql_connect( DB_HOST, DB_USER, DB_PASSWD ) or die( "No se ha podido conectar a la BBDD. Contacte con el administrador (Codigo 000).");
	//selecciona la BBDD
	mysql_select_db( DB_NAME, $idCon );
	//establece la codificacion de las consultas en utf8
	mysql_query("SET NAMES 'utf8'");
	
	//comprobacion de la BBDD sobre la tabla test
	compruebaDB($idCon);
	//si seguimos, todo es correcto, devuelvo el enlace
	
	return $idCon;
}

//cierra la conexion a MySQL
function desconectaDb($idCon)
{
	mysql_close($idCon);
}

//comprueba la bbdd
function compruebaDB($idCon)
{
	$aPrueba="";
	$cSql = "SELECT valor FROM Test";
	if ($idQry = mysql_query( $cSql, $idCon ))
	{
	$aPrueba = mysql_fetch_array( $idQry );
	}

    if( $aPrueba!="" )
    {
        if( $aPrueba[ "valor" ]!="abcde")
        {
        	desconectaDb($idCon);
        	die ("Error de lectura: no hay datos o los permisos no son adecuados. \n Contacte con el administrador (Código 001)");
        }
    }
    else
    {
       	desconectaDb($idCon);
		die ("Imposible conectar. \n Contacte con el administrador (Codigo 002).");
    }
}
?>
<?php
////////////////////////////
//
//	 MyAbies: estatico.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
// beginabies -> cabecera de la página
// endabies -> pie de la pagina
//
////////////////////////////


////////////////////////////
//	beginAbies
//
//	Datos del centro y comienzo de las tablas de la página.
//
///////////////////////////////////////////////
function beginAbies()
{
	global $ruta;
	//titulo y enlace externo de la web
	//valores por defecto
		$enlaceurl=$ruta;
		$textourl="MyAbies";
	if (file_exists("content/data/enlace.php"))
	{
		include_once("content/data/enlace.php");
		//este fichero contiene $enlaceurl y $textourl. Texto enlace no debe ser mayor de 20 caracteres, para que se vea bien.
		//si existe, se habran actualizado los valores por defecto.
	}
	//puede que textourl estuviera vacio, en ese caso vuelvo por defecto 
	if ($textourl=="")
	{
		$textourl="MyAbies";
		$titulo_web="MyAbies";
	}
	else
	{
		$titulo_web=$textourl;
	}

	//conecto a la BBDD y saco los datos del centro.


	include_once "conexion.php";
	$idCon = conectaDb();
	$cSql = "SELECT * FROM centro";
	if ($idQry = mysql_query( $cSql, $idCon ))
	{
		$aCentro = mysql_fetch_array( $idQry );
	}
	desconectaDb($idCon);
	
?>

<div id="header">
		<div id="logo">
			<h1><a href="<?php echo $enlaceurl ?>"><? echo $textourl ?></a></h1>
		
<?
    if( $aCentro!="" )
    {

  	    printf( "<h2>" );
        if( $aCentro[ "Centro" ] )    printf( "%s<br/>", $aCentro[ "Centro" ] );
        if( $aCentro[ "Direccion" ] ) printf( "%s<br/>", $aCentro[ "Direccion" ] );
        if( $aCentro[ "Localidad" ] ) printf( "%s<br/>", $aCentro[ "Localidad" ] );
        if( $aCentro[ "CodPostal" ] ) printf( "%s %s<br/>", $aCentro[ "CodPostal" ], $aCentro[ "Provincia" ] );

        printf( "</h2>" );
    }
?>
		</div>
		<div id="menu">
	    	<ul>
	    		<li class="current_page_item"><a href="<? echo $ruta ?>?reinicio=1">Inicio</a></li>
				<li><a href="content/ayuda.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">AYUDA</a></li>
	    		<li class="last"><a href="content/acerca.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">Acerca de MyAbies</a></li>
	    	</ul>
		</div>
</div>
<div id="page">
	<div id="content">
	    <p id="head"><a onclick="javascript:mostrarheader();"><span id="textohead">Consulta al catálogo ABIES de la biblioteca</span></a></p>
<?
}
///////////////////////////////////////////////
//
//	endAbies
//
///////////////////////////////////////////////
function endAbies()
{
?>
    <p id="pie">
    <span id="piemyabies"> <a href="http://myabies.hfiel.es" target="_blank" onmouseover="javaqscript:mostrarlogospie()">MyAbies</a></span>
	<span id="logospie">
	<a href="http://www.php.net">
		<img src="img/php.png"
        title="Creado con PHP" alt="Creado con PHP" height="31" width="88" />
	</a>
	<a href="http://www.mysql.com">
		<img src="img/mysql.png"
        title="Movido por MySQL" alt="Movido por MySQL" height="31" width="61" />
	</a>
	<a href="http://validator.w3.org/check?uri=referer">
		<img src="img/xhtml.png"
        title="XHTML 1.0 Transitional Válido" alt="XHTML 1.0 Transitional Válido" height="31" width="88" />
	</a>
	<a href="http://jigsaw.w3.org/css-validator/check/referer">
		<img src="img/css.gif"
		title="CSS Válido" alt="CSS Válido" height="31" width="88" />
    </a>
    </span>

</p>
    </div>
    </div>
    </div>
    </body>
	</html>
<?
}


?>
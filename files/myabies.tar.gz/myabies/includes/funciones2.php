<?php
////////////////////////////
//
//	 MyAbies: funciones2.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
// FUNCIONES 
//
// compruebaDB -> Test de la BBDD
// ioClean -> Limpia una cadena de caracteres peligrosos 
// ioCleanEstricta -> Limpia una cadena, solo letras y numeros
//
// formLogin
// formClave
// formDB
// formEnlace
// fomrFichero
// crearDB
// cargaScript
// gestionAdm
// gestionDb
// gestionEnlace
// 
///////////////




//////////////////////////////////////////////////////////////
//															//
// compruebaDB												//
//															//
// Comprueba que la base de datos es accesible,				//
// se pueden leer datos y no esta vacia						//
//////////////////////////////////////////////////////////////

function compruebaDB()
{
	global $idCon;
	$cSql = "SELECT valor FROM test";
	$idQry = mysql_query( $cSql, $idCon );
	$aPrueba = mysql_fetch_array( $idQry );

    if( $aPrueba!="" )
    {
        if( $aPrueba[ "valor" ]!="abcde")
        {
        	die ("Error de lectura: no hay datos o los permisos no son adecuados. \n Contacte con el administrador (Código 001)");
        }
    }
    else
    {
		die ("Error de lectura: no hay datos o los permisos no son adecuados. \n Contacte con el administrador (Código 002)");
    }
}


///////////////////////////////////////////////
//
//	ioClean e ioCleanEstricta
//
//	Recibe una cadena y devuelve la cadena sin
//	los caracteres peligrosos.
//
//  ioClean:
//	Sólo se permiten letras (inc. ñ y acentos), numeros,
//	espacios y comas. Para los campos de búsqueda (autor, titulo, etc.)
//
//  ioCleanEstricta:
//  Sólo letras y números, se usa para el get de paginación y ordenación
//
///////////////////////////////////////////////
function ioClean($sucia)
{
	//primero limpio de caracteres prohibidos SIN contar los guiones -
	$temp=preg_replace("/[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑäëïöüàèìòùâêîôûÄËÏÖÜÀÈÌÒÙÂÊÎÔÛ\.\-, ]/","",$sucia);
	//limpio si aparecen más de 2 guiones seguidos (evito inyeccion por comentario)
	return preg_replace("/[\-]{2,}/","",$temp);
}

function ioCleanEstricta($sucia)
{
	//solo permite letras (a-z A-Z) y numeros (0-9)
	$temp=preg_replace("/[^a-zA-Z0-9]/","",$sucia);
	return $temp;
}


//
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////      FORMULARIOS    ////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//////
// formLogin
//
// genera el formulario de login
//
//////

function formLogin()
{
	global $url;
?>
<div id="wrapper">
<div id="page">
	<div id='caja'>
		<div id='head'>
		<a href="index.php">MyAbies</a>
		</div>

		<div id='centro'>
			<div id='acceso'>
				<form class='login' action='<?=$url?>' name="formbus" method='post'>
					<label>Usuario</label>
					<input type='text' name='u' id="autor"><br/>
					<label>Clave</label>
					<input type='password' name='ps'><br/>
					<input type='submit' name='a' value='Enviar'><br/>
				</form>
			</div>
		<a href="index.php">Volver a la página principal.</a>
		</div>
	</div>
	</div>
</div>
<?
}


//////
// formClave
//
// genera el formulario de cambio de nombre y clave
//
//////

function formClave()
{
	global $url, $us;
?>
<div id="wrapper">
<div id="page">
	<div id='caja'>
		<div id='head'>
		MyAbies: Cambio de claves
		</div>

		<div id='centro'>
		<h3>Introduzca los nuevos datos de acceso a la zona de administración:</h3>
			<div id='acceso'>
				<form class='login' action='<?=$url?>' method='post'>
					<label>Usuario</label>
					<input type='text' name='u'
<?php 
	if (isset($us) AND $us!="")
	{
		echo " value='". $us . "'";
	}
?>
><br/>
					<label>Clave</label>
					<input type='password' name='ps'><br/>
					<label>Repita la clave</label>
					<input type='password' name='ps2'><br/>
					<input type='submit' name='c' value='Enviar'><br/>
				</form>
			</div>
		</div>
		<div id='salir'>
			<a href="<?$direcc?>?r=1">Salir</a> - <a href="content/ayuda2.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">Ayuda administración</a> - <a href="<?$direcc?>?a=1">Actualizar MyAbies</a> - <a href="<?$direcc?>?d=1">Cambiar datos de conexion</a> - <a href="<?$direcc?>?e=1">Configurar titulo</a>
		</div>
	</div>
	</div>
</div>
<?
}


//////
// formDB
//
// genera el formulario de configuracion de la base de datos
//
//////

function formDB()
{
	global $url;
?>
<div id="wrapper">
<div id="page">
	<div id='caja'>
		<div id='head'>
		MyAbies: Configuración de conexion
		</div>

		<div id='centro'>
		<h3>Introduzca los datos de conexión a la BBDD:</h3>
			<div id='acceso'>
				<form class='login' action='<?=$url?>' method='post'>
					<label>Servidor MySQL: <a href="" onclick="return alert('Si servidor no utiliza el puerto por defecto (3306), deberá indicar el puerto de la forma servidor:puerto, por ejemplo localhost:8889');">?</a></label>
					
<?php
	echo "<input type='text' name='s'";
	if (defined("DB_HOST"))
	{
		echo " value='". DB_HOST . "'";
	}
	echo "><br/>\n";
?>

					<label>Usuario:</label>
<?php 
	echo "<input type='text' name='u'";
	if (defined("DB_USER"))
	{
		echo " value='". DB_USER . "'";
	}
	echo "><br/>\n";
?>
					<label>Clave:</label>
<?php
	echo "<input type='password' name='ps'";
	if (defined("DB_PASSWD"))
	{
		echo " value='". DB_PASSWD . "'";
	}
	echo "><br/>\n";
?>
					<label>Nombre de la base de datos:</label>
					
<?php 
	echo "<input type='text' name='n'";
	if (defined("DB_NAME"))
	{
		echo " value='". DB_NAME . "'";
	}
	echo "><br/>\n";
?>
					<input type='submit' name='d' value='Enviar'><br/>
				</form>
			</div>
		</div>
		<div id='salir'>
			<a href="<?$direcc?>?r=1">Salir</a> - <a href="content/ayuda2.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">Ayuda administración</a> - <a href="<?$direcc?>?a=1">Actualizar MyAbies</a> - <a href="<?$direcc?>?c=1">Cambiar claves</a> - <a href="<?$direcc?>?e=1">Configurar titulo</a>
		</div>
	</div>
	</div>
</div><?
}



//////
// formEnlace
//
// genera el formulario de configuración de enlace del centro
//
// Este enlace aparece en la página inicial, junto al logo, con el texto indicado
// Si no se configura, se pone por defecto en MyAbies, apuntando a index.php
//
//////

function formEnlace()
{
	global $url, $us, $textourl, $enlaceurl;
?>
<div id="wrapper">
<div id="page">
	<div id='caja'>
		<div id='head'>
		MyAbies: Título y enlace al centro
		</div>

		<div id='centro'>
		<h3>Puede definir un texto y un enlace (PE, a la Web de biblioteca o del centro educativo), para que aparezca como título en la página inicial.</h3>
			<div id='acceso'>
				<form class='login' action='<?=$url?>' method='post'>
					<label>Título <a href="" onclick="return alert('El título puede ocupar hasta 20 caracteres, pero es posible que textos demasiado largos no se ajusten correctamente al diseño. Se recomienda emplear hasta 15 caracteres.');">?</a></label>
<?php 
	echo "<input type='text' name='textourl' size='25' maxlength='20' ";
	if (isset($textourl) AND $textourl!="")
	{
		echo " value='". $textourl . "'";
	}
	echo "><br/>\n";
?>
					<label>Direccion Web (incluyendo http://)</label>
<?php 
	echo "<input type='text' name='enlaceurl' size='50'";
	if (isset($enlaceurl) AND $enlaceurl!="")
	{
		echo " value='". $enlaceurl . "'";
	}
	echo "><br/>\n";
?>
					<input type='submit' name='e' value='Enviar'><br/>
				</form>
			</div>
		</div>
		<div id='salir'>
			<a href="<?$direcc?>?r=1">Salir</a> - <a href="content/ayuda2.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">Ayuda administración</a> - <a href="<?$direcc?>?a=1">Actualizar MyAbies</a> - <a href="<?$direcc?>?c=1">Cambiar claves</a> - <a href="<?$direcc?>?d=1">Cambiar datos de conexion</a>
		</div>
	</div>
	</div>
</div>
<?
}


//////
// formFichero()
//
// genera una web completa con el formulario de login, para enviar a admin.php
//
//////

function formFichero()
{
	global $direcc, $ruta;
?>
<div id="wrapper">
<div id="page">
	<div id='caja'>
		<div id='head'>
		Actualización de MyAbies
		</div>
		<div id="lista">
			<br/>
			<p>
			Siga este proceso para actualizar MyAbies desde el equipo donde tenga instalado Abies 2:
				<ol>
					<li>Ejecute el asistente para exportación (fichero <a href="./content/files/myabiesmdb.zip">myabies.mdb</a>) y siga las instrucciones.</li>
					<li>Haga clic en el botón <em>Examinar</em> (o <em>Seleccionar archivo</em>, dependiendo de su sistema) en esta página, y localize el fichero <strong>myabiesdump.sql</strong> en la raíz de la unidad <strong>C:/</strong> de su PC.</li>
					<li>Haga clic en el boton <strong>Enviar</strong> en esta página y espere. El proceso de actualización puede tardar algunos minutos.</li>
				</ol>
			</p>
			<form action="<? echo $direcc ?>" method="post" enctype="multipart/form-data">
			<label for="file">Localizar <em>myabiesdump.sql</em>&#8594;</label>
			<input type="file" name="file" id="file" />
			<br />
			<input type="submit" name="a" value="Enviar" />
			</form>
			<br/>
		</div>
	<hr>
		<div id='salir'>
			<a href="<?$direcc?>?r=1">Salir</a> - <a href="content/ayuda2.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">Ayuda administración</a> - <a href="<?$direcc?>?c=1">Cambiar claves</a> - <a href="<?$direcc?>?d=1">Cambiar datos de conexion</a> - <a href="<?$direcc?>?e=1">Configurar titulo</a>
		</div>
	</div>
</div>
</div>
<?

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////      FUNCIONES BASE DATOS    //////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////
//
// crearDB
//
// crea la base de datos myabies en el servidor MySQL
//////
function crearDB()
{
	$conexion = mysql_connect(DB_HOST,DB_USER,DB_PASSWD);
	if (!$conexion)
	{
		echo "No se pudo conectar con el servidor de base de datos.<br/>";
		die("Por favor, contacte con el administrador (ERROR 003)<br/>" . mysql_error());
	}
		mysql_query("SET NAMES 'utf8'", $conexion);
	$sql="CREATE DATABASE IF NOT EXISTS `".DB_NAME."` DEFAULT CHARACTER SET utf8";
	if (!mysql_query($sql, $conexion))
	{
		die("No se pudo crear la BBDD (ERROR 005)<br/>");
	}
	mysql_close($conexion);
	
}



//////
// cargaScript
//
// lanza el script contra el servidor de BBDD
//
//////


function cargaScript($fichero)
{
	global $direcc;
?>
<div id="wrapper">
<div id="page">
<?
	echo "<h3>Actualizando la base de datos...</h3><br/>\n";
	echo "Consulte el resultado al final de la página<br/>\n";
	echo "Si se producen errores, se indicaran a continuación.<br/>\n";
	echo "<hr>\n";
	$conexion = mysql_connect(DB_HOST,DB_USER,DB_PASSWD);
	if (!$conexion)
	{
		echo "No se pudo conectar (¿datos incorrectos?)<br/>";
		die("Por favor, contacte con el administrador (ERROR 003)<br/>" . mysql_error());
	}
	
	
	if (!mysql_select_db( DB_NAME, $conexion ))
	{
		//creo la bbdd
		crearDB();
		//cierro la conexion
		mysql_close($conexion);
		//abro de nuevo la conexion
		$conexion = mysql_connect(DB_HOST,DB_USER,DB_PASSWD);
			//selecciono de nuevo la bbdd
			if (!mysql_select_db( DB_NAME, $conexion ))
			{
				die("No se pudo conectar a la BBDD recién creada (ERROR 006)<br/>". mysql_error());
			}
	}
	mysql_query("SET NAMES 'utf8'", $conexion);

/////
//
//Lectura y query usando fgets
	$correcta=0;
	$fallos=0;
	$handle = fopen($fichero, 'r');
	$i=0;
	while (!feof($handle))
	{
		$i++;
		//se leen 2048 caracteres de cada linea. Si las lineas son demasiado largas, pueden verse truncadas
		$Data = fgets($handle, 2048);
		$DataU= mb_convert_encoding($Data, 'UTF-8', mb_detect_encoding($Data, 'UTF-8, ISO-8859-1', true));

		if ($DataU != "")
		{

			if (mysql_query($DataU,$conexion))
			{
				$correcta++;
			}
			else
			{
				echo "Error (línea " . $i . "): " . $DataU . ": " . mysql_error() . "<br/> \n";
				$fallos++;
			}
		}
	}
	fclose($handle); 
	mysql_close($conexion);
	echo "<hr>\n";
	echo "<h3>Actualización completa.</h3><br/>\n";
	
	echo "Líneas procesadas correctamente: " . $correcta ."<br/>\n";
	echo "Fallos: " .$fallos ."<br/>\n";
	
	if ($fallos!=0)
	{
?>
	<h2>Ayuda</h2>
	Pueden producirse algunos errores (lineas en blanco, valores duplicados...). Si el nº de errores es muy elevado, compruebe los datos de conexión a la BBDD y los permisos asignados al usuario.
	El texto que acompaña al error puede ayudarle a identificar el problema.
	
	<h3>Errores no graves:</h3>
	<ul>
		<li>Si el error indica <emph>Query was empty</emph>, se puede ignorar con tranquilidad.</li>
		<li>En caso de que aparezca un error sobre <emph>INSERT INTO</emph>, compruebe si aparece el texto <emph>Duplicate entry</emph>. En caso afirmativo, su base de datos Abies contiene valores duplicados para algún dato. Es muy posible que pueda ignorar este error sin problemas. Sin embargo, debería intentar localizar y corregir el error en su BBDD Abies.</li>
	</ul>
<?
	}
?>
		<div id='salir'>
			<a href="<?$direcc?>?r=1">Salir</a> - <a href="content/ayuda2.php" target="_blank" onclick="window.open(this.href, this.target, 'width=800,scrollbars=1'); return false;">Ayuda administración</a> - <a href="<?$direcc?>?a=1">Actualizar MyAbies</a>
		</div>
</div>
</div>
<?
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////      GESTION CONFIGURACION Y FORMULARIOS    ////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////


///////
// Gestion de ficheros de configuracion
//
// gestionAdm();
///////
function gestionAdm()
{
	global $long_min, $us, $direcc;
	//compruebo si ha se han recibido datos
	// datos de usuario de administracion
	if (isset($_POST['c']) AND $_POST['c']!="")
	{
		
		if (isset($_POST['u']) AND isset($_POST['ps']) AND isset($_POST['ps2']))
		{
			//tengo todos los datos, compruebo que coinciden las claves
			if ($_POST['ps']==$_POST['ps2'])
			{
				//compruebo la longitud de las claves. Empleo mb_strlen, que devuelve la longitud, sin importar la codificacion
				///(los caracteres multibyte se cuentan como 1 ocurrencia)
				if (mb_strlen($_POST['ps'])>=$long_min)
				{
					echo "<div id=\"aviso\"><h3>Almacenando las claves...</h3>\n";
				
					if ($f=fopen("content/data/adm.php","w","b"))
					{
						fputs($f,"<?php \n");
						fputs($f,"\$usuario_valido=\"" . $_POST['u'] . "\";\n");
						fputs($f,"\$clave_valida=\"" . sha1($_POST['ps']) . "\";\n");
						fputs($f,"?> \n");
						fclose($f);
						if (isset($_SESSION['usuario']))
						{
							$_SESSION['usuario']="";
							unset($_SESSION['usuario']);
						}
						echo "<h3>Claves almacenadas con éxito.<br/>Al finalizar al configuración, deberá volver a conectarse con los nuevos datos.<br/><a href=\"".$direcc."\">Continuar</a></h3>";
						header("Refresh:3;$direcc");
					}
					else
					{
						echo "<h3>Error al crear el fichero de claves, compruebe que posee los permisos adecuados en la carpeta <em>content/data</em></h3>\n";	
					}
					echo "</div>\n";
				}
				else
				{
					echo "<div id=\"aviso\"><h3>La clave es demasiado corta.</h3></div>\n";
					$us=$_POST['u'];
					formClave();
				}
			}
			else
			{
				//claves no coinciden
				echo "<div id=\"aviso\"><h3>Las claves no coinciden.</h3></div>\n";
				$us=$_POST['u'];
				formClave();
			}
		}
		else
		{
			//faltan datos, se informa:
			if (!isset($_POST['u']))
			{
				echo "<div id=\"aviso\"><h3>Falta el nombre de usuario.</h3></div>\n";
			}
			else
			{
				$us=$_POST['u'];
			}
			if (!isset($_POST['ps']) OR !isset($_POST['ps2']))
			{
				echo "<div id=\"aviso\"><h3>Falta la clave. Debe rellenar ambos campos de clave.</h3></div>\n";
			}
			formClave();
		}
	}
	else //no se han recibido datos, muestro el formulario.
	{
		formClave();
	}
}

///////
// Gestion de ficheros de configuracion
//
// gestionDb();
///////
function gestionDb()
{
	//compruebo si se han recibido datos
	//datos de conexion bbdd
	if (isset($_POST['d']) AND $_POST['d']!="")
	{
		if (isset($_POST['s']) AND isset($_POST['u']) AND isset($_POST['ps']) AND isset($_POST['n']))
		{
			//tengo todos los datos, almaceno
			echo "<div id=\"aviso\"><h3>Almacenando configuración...</h3>\n";
		
			if ($f=fopen("content/data/db.php","w","b"))
			{
				fputs($f,"<?php \n");
				fputs($f,"define( \"DB_TYPE\",           \"MySQL\" );\n");
				fputs($f,"define( \"DB_HOST\",           \"".$_POST['s']."\" );\n" );
				fputs($f,"define( \"DB_USER\",           \"".$_POST['u']."\" );\n" );
				fputs($f,"define( \"DB_PASSWD\",           \"".$_POST['ps']."\" );\n" );
				fputs($f,"define( \"DB_NAME\",           \"".$_POST['n']."\" );\n" );
				fputs($f,"?> \n");
				fclose($f);
				echo "<h3>Configuración almacenada con éxito. Recargando la página...<br/><a href=\"".$direcc."\">Continuar</a></h3>";
				header("Refresh:2;$direcc");
			}
			else
			{
				echo "<h3>Error al crear el fichero de configuración, compruebe que posee los permisos adecuados en la carpeta <em>content/data</em></h3>\n";	
			}
			echo "</div>\n";
		}
		else
		{
			//faltan datos, se informa:
			if (!isset($_POST['s']))
			{
				echo "<div id=\"aviso\"><h3>Falta el nombre del servidor.</h3></div>\n";
			}
			else
			{
				$serv=$_POST['s'];
			}
			if (!isset($_POST['u']))
			{
				echo "<div id=\"aviso\"><h3>Falta el nombre de usuario.</h3></div>\n";
			}
			else
			{
				$us=$_POST['u'];
			}
			if (!isset($_POST['ps']))
			{
				echo "<div id=\"aviso\"><h3>Falta la clave.</h3></div>\n";
			}
			if (!isset($_POST['n']))
			{
				echo "<div id=\"aviso\"><h3>Falta el nombre de la base de datos.</h3></div>\n";
			}
			else
			{
				$nomdb=$_POST['n'];
			}
			formDB();
		}
	}
	else
	{
		formDB();
	}
}

///////
// Gestion de ficheros de configuracion
//
// gestionEnlace();
//
// Configuración titulo y enlace externo a mostrar en la pagina principal
//
///////


function gestionEnlace()
{
	//compruebo si se han recibido datos
	//datos de conexion bbdd
	if (isset($_POST['e']) AND $_POST['e']!="")
	{
		if (isset($_POST['textourl']) AND isset($_POST['enlaceurl']))
		{
			//tengo todos los datos, almaceno
			echo "<div id=\"aviso\"><h3>Almacenando enlace externo...</h3>\n";
		
			if ($f=fopen("content/data/enlace.php","w","b"))
			{
				fputs($f,"<?php \n");
				fputs($f,"\$textourl=\"" . $_POST['textourl'] . "\";\n");
				fputs($f,"\$enlaceurl=\"" . $_POST['enlaceurl'] . "\";\n");
				fputs($f,"?> \n");
				fclose($f);
				echo "<h3>Enlace almacenado con éxito.<br/><a href=\"".$direcc."\">Continuar</a></h3>";
				header("Refresh:3;$direcc");
			}
			else
			{
				echo "<h3>Error al guardar el enlace, compruebe que posee los permisos adecuados en la carpeta <em>content/data</em></h3>\n";	
			}
			echo "</div>\n";
		}
		else
		{
			//faltan datos, se informa:
			if (!isset($_POST['textourl']))
			{
				echo "<div id=\"aviso\"><h3>Falta el texto a mostrar en el enlace.</h3></div>\n";
			}
			else
			{
				$textourl=$_POST['textourl'];
			}
			if (!isset($_POST['enlaceurl']))
			{
				echo "<div id=\"aviso\"><h3>Falta la dirección URL para el enlace.</h3></div>\n";
			}
			else
			{
				$enlaceurl=$_POST['enlaceurl'];
			}
			formEnlace();
		}
	}
	else
	{
		formEnlace();
	}
}

?>
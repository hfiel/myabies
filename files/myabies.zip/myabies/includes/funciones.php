<?php

////////////////////////////
//
//	 MyAbies: funciones.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
// FUNCIONES
//
// ioClean -> Limpia una cadena de caracteres peligrosos 
// ioCleanEstricta -> Limpia una cadena, solo letras y numeros
// cargaPost -> Carga los POST en un array limpio
// fichaFondo -> Muestra detalles de un resultado concreto
// listadoFondos -> Muestra resultado de busqueda
// reinicio -> Reinicio y recarga index
//
///////////////


///////////////////////////////////////////////
//
//	ioClean e ioCleanEstricta
//
//	Recibe una cadena y devuelve la cadena sin
//	los caracteres peligrosos.
//
//  ioClean:
//	Sólo se permiten letras (inc. ñ y acentos), numeros,
//	espacios y comas. Para los campos de búsqueda (autor, titulo, etc.)
//
//  ioCleanEstricta:
//  Sólo letras y números, se usa para el get de paginación y ordenación
//
///////////////////////////////////////////////
function ioClean($sucia)
{
	//primero limpio de caracteres prohibidos SIN contar los guiones -
	$temp=preg_replace("/[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑäëïöüàèìòùâêîôûÄËÏÖÜÀÈÌÒÙÂÊÎÔÛ\.\-, ]/","",$sucia);
	//limpio si aparecen más de 2 guiones seguidos (evito inyeccion por comentario)
	return preg_replace("/[\-]{2,}/","",$temp);
}

function ioCleanEstricta($sucia)
{
	//solo permite letras (a-z A-Z) y numeros (0-9)
	$temp=preg_replace("/[^a-zA-Z0-9]/","",$sucia);
	return $temp;
}


///////////////////////////////////////////////
//
//	cargaPost
//
//	Lee los POST recibidos, limpia el contenido
//	y guarda en array indexado
//
///////////////////////////////////////////////
function cargaPost()
{
	$arrTmp=array();
	foreach ($_REQUEST as $clave => $valor)
	{
		//limpio variable usando temporal
		$tmp=ioClean($valor);
		if ($tmp!="") //si queda algo despues de limpiar...
		{
			$arrTmp[$clave]=$tmp;
		}
	}
	return $arrTmp;
}




///////////////////////////////////////////////
//
//	fichaFondo
//
//	Muestra los datos de ejemplares de un fondo concreto
//	Y muestra todos los ejemplares disponibles
//
///////////////////////////////////////////////
function fichaFondo( $idFondo )
{
    global $url;
	global $arrPost;
    $cSql = sprintf( "SELECT `F`.`ISBN`, DepositoLegal, Editorial FROM fondos F LEFT JOIN ejemplares E on F.IdFondo=E.IdFondo JOIN editoriales D on F.IdEditorial=D.IdEditorial WHERE F.IdFondo = %s", $idFondo );
	include_once "conexion.php";
	$idCon = conectaDb();
    $idQry = mysql_query( $cSql, $idCon );
   $idRec = mysql_fetch_array( $idQry );
   if ($idRec['ISBN']!="" OR $idRec['Aplicacion']!="" OR $idRec['Ubicacion']!="" OR $idRec['DepositoLegal']!="" OR $idRec['Editorial']!="")
   {
		printf( "<table border=\"1\" width=\"100%%\" class=\"listado\">\n" );

		printf( "<tr class=\"cabecera\">\n" );

		printf( "<th>%s</th>\n", "I.S.B.N" );
		printf( "<th>%s</th>\n", "Depósito Legal" );
		printf( "<th>%s</th>\n", "Editorial" );
		printf( "</tr>\n" );
		printf( "<tr class=\"listado\">\n" );


		printf( "<td>%s</td>\n", $idRec[ "ISBN" ] );
		printf( "<th>%s</th>\n", $idRec[ "DepositoLegal" ] );
		printf( "<th>%s</th>\n", $idRec[ "Editorial" ] );
		printf( "</tr>\n" );
		printf( "</table>\n" );
	}
    $cSql = sprintf( "SELECT cdescriptor FROM fondos_descriptores fd , descriptores d WHERE fd.idfondo = %s  AND fd.iddescriptor= d.iddescriptor", $idFondo );
    $idQry = mysql_query( $cSql, $idCon );
    if( mysql_num_rows( $idQry ) ) 
    {
    	printf( "<table border=\"1\" width=\"100%%\" class=\"listado\">" );
       printf( "<tr class=\"cabecera\"><th>%s</th></tr>", "Descriptores" );
       printf( "<tr class=\"listado\"><td>" );
	   while( $idRec = mysql_fetch_array( $idQry ) )
	   printf( "%s<br/>", $idRec[ "cdescriptor" ] );
	   printf( "</td></tr></table>" );
  
	}

    
    $cSql = sprintf( "SELECT * FROM ejemplares WHERE ejemplares.IdFondo = %s", $idFondo );
    $idQry = mysql_query( $cSql, $idCon );
    printf( "<table border=\"1\" width=\"100%%\" class=\"listado\">" );
    printf( "<tr class=\"cabecera\">" );
    printf( "<th>%s</th>", "Ejemplar" );
    printf( "<th>%s</th>", "Signatura" );
    printf( "<th>%s</th>", "Prestado" );
    printf( "</tr>" );
    if ( mysql_num_rows( $idQry ) )
	    while( $idRec = mysql_fetch_array( $idQry ) )
	    {
	        printf( "<tr class=\"listado\">" );
	        printf( "<td>%s</td>", $idRec[ "CodigoEjemplar" ] );
	        printf( "<td>%s-%s-%s</td>", $idRec[ "Sig1" ], $idRec[ "Sig2" ], $idRec[ "Sig3" ] );
	        printf( "<td>%s</td>", $idRec[ "Prestado" ] ? "Sí" : "No" );
	        printf( "</tr>" );
	    }
    else
	printf( "<tr class=\"listado\"><td>%s</td></tr>", "No hay ejemplares" );
    printf( "</table>" );
	
	
	// estamos en un libro concreto, muestro la vuelta a la consulta anterior 
		printf( "<form action=\"%s\" method=\"post\">", $url );
		foreach ($arrPost as $k=>$v)
		{
			if( $k != "idFondo" )
				printf( "<input type=\"hidden\" name=\"%s\" value=\"%s\" />", $k, $v );
		}
		printf( "<table width=\"100%%\"><tr><td align=\"center\">" );
		printf( "Volver a la consulta anterior. <input type=\"image\" src=\"%s\" />", "img/volverconsulta.png" );
		printf( "</td></tr></table>" );
		printf( "</form>" );
	//fin de vuelta a la consulta original
		desconectaDb($idCon);

}


///////////////////////////////////////////////
//
//	listadoFondos
//
//	Muestra la lista de fondos recuperada
//	Incluye paginacion
//
///////////////////////////////////////////////
function listadoFondos( $cTexto, $cSql,$orden="titulo",$direc="ASC", $paginaSolicitada=1)
{

    global $url;
	global $ruta;
    global $arrPost;
    global $cuantos_pag;

	//primero añado el orden a la consulta
	$cSql1=$cSql." ORDER BY ".$orden." ".$direc;
	
	//segundo la paginacion
	//lanzo la consulta (almacenada en $cSql)	
	//esta la utilizo para contar el total de resultados.
		include_once "conexion.php";
	$idCon = conectaDb();
    $idQry = mysql_query( $cSql, $idCon );
	$nRecuperados = mysql_num_rows( $idQry );
	//calculo total de paginas
	$totalpag = (int) ($nRecuperados / $cuantos_pag); //paginas completas
	//si me llega una pagina mala (menor o igual a 0, mayor que el total de pags), la pongo predeterminada a 1
	if ($paginaSolicitada<=0 OR $paginaSolicitada>$totalpag+1)
	{
		$paginaSolicitada=1;
	}
	//si la ultima pagina no esta completa, habrá que añadir 1 más al total del paginas
	if ( ($nRecuperados / $cuantos_pag) >$totalpag)
	{
		
		$totalpag++;
	}

	//calculo primer registro pagina actual
	$primero_lista=(($paginaSolicitada-1)*$cuantos_pag);

	//calculo el ultimo registro de esta página.
	//a) si hay mas de una pagina, y no estoy en la ultima, será $primero_lista + $cuantos_pag
	//b) si no hay mas de una pagina o si estoy en la ultima, será: nRecuperados-(paginas_pasadas*cuantos_pag)
	if ($totalpag>$paginaSolicitada)
	{
		$ultimo_lista=$primero_lista+$cuantos_pag;
	}
	else
	{
		$ultimo_lista=$nRecuperados-(($totalpag-$paginaSolicitada)*$cuantos_pag);
	}

	//modifico la consulta para añadir los LIMIT para paginacion
	$cSql2=$cSql1." LIMIT ".$primero_lista.",".$cuantos_pag;
	
	//lanzo la consulta con los limites incluidos
	//esta es la que uso para mostrar los resultados
	$idQry = mysql_query( $cSql2, $idCon );

	//comienza salida
	printf( "<table border=\"1\" width=\"100%%\" class=\"listado\" id=\"soyyo\">\n" );
	//si tengo resultados
    if( $nRecuperados > 0 )
    {
		//si tengo mas de un resultado: a) no ha sido consulta detalle b) se ha obtenido mas de un fondo en consulta general
		if ( $nRecuperados > 1 )
		{
			printf( "<tr class=\"busqueda\"><th colspan=\"7\">Búsqueda [ %s ]\n", $cTexto );
			printf( "<br/>Encontrados %d resultados. Página %d de %d (%d al %d)\n", $nRecuperados, $paginaSolicitada, $totalpag, $primero_lista+1,$ultimo_lista );

			//si hay mas de 1 página...
			//muestro en pantalla la paginacion:
			if ($totalpag>=1)
			{						
				printf("<br/>\n");
					
					if ($paginaSolicitada>2)
					{
						echo "<a href=\"$url?p=1\">&lt;&lt; Primera</a>   \n";
					}

					if ($paginaSolicitada<>1)
					{
						echo "  <a href=\"$url?p=";
						echo $paginaSolicitada -1;
						echo "\"> &lt; Anterior</a>\n ";
					}

					if ($totalpag>1)
					{
						for ($i=1;$i<=$totalpag;$i++)
						{
							if ($paginaSolicitada==$i)
							{
								echo " ".$paginaSolicitada." \n";
							}
							else
							{
								echo " <a href=\"$url?p=$i\">$i</a> \n";
							}
						}
					}
					if ($paginaSolicitada<$totalpag)
					{
						echo " <a href=\"$url?p=";
						echo $paginaSolicitada +1;
						echo "\">Siguiente &gt;</a>  \n";
					}

					if ($paginaSolicitada<$totalpag-1)
					{
						echo "  <a href=\"$url?p=$totalpag\">Ultima &gt;&gt;</a> \n";
					}
			}
			//fin calculo paginacion
			printf( "</th></tr>");
 		} //fin "si hay mas de un registro recuperado"
		else //solo hay un resultado: a) busqueda directa b)unico resultado en consulta general
		{
			if ( $arrPost['idFondo']==0 )
			{
				printf( "<tr class=\"busqueda\"><th colspan=\"7\">Búsqueda [ %s ] <br/>Encontrado 1 resultado.</th></tr>\n", $cTexto );
			}
			else
			{
				printf( "<tr class=\"busqueda\"><th colspan=\"7\">Detalles del fondo</th></tr>\n" );
			}
		}
		
		//cabecera tabla resultados generales
		printf( "<tr class=\"cabecera\">\n" );
	    if( $cTexto )
		{ 
			printf( "<th>%s</th>\n", "Detalles" );
			printf( "<th><a href=\"%s?orden=titulo\">Título</a></th>\n", $ruta );
			printf( "<th><a href=\"%s?orden=a\">Autor</a></th>\n", $ruta );
		}
		else
		{
			printf( "<th>%s</th>\n","Título" );
			printf( "<th>%s</th>\n","Autor" );
		}
		

		//titulo columnas, con enlace para ordenacion
		
	
        
		printf( "<th>%s</th>\n", "Disp." );

        printf( "</tr>\n" );
	    while( $idRec = mysql_fetch_array( $idQry ) )
  
	    {
	        printf( "<tr class=\"listado\">\n" );
			//columna detalles, para buscar datos de un fondo concreto
			if( $cTexto )
            {
				printf( "<td align=\"center\"><form action=\"%s\" method=\"post\">\n", $url );


				foreach ($arrPost as $k=>$v)
				{
	                printf( "<input type=\"hidden\" name=\"%s\" value=\"%s\" />\n", $k, $v );
				}
				printf( "<input type=\"hidden\" name=\"%s\" value=\"%s\" />\n", "idFondo", $idRec[ "IdFondo" ] );
				printf( "<input type=\"image\" src=\"%s\" />\n", "img/librarian.gif" );
				printf( "</form></td>" );
	
	        }
			//columna titulo
            printf( "<td>%s</td>\n", $idRec[ "Titulo" ] );
			//columna autor
	        printf( "<td class=\"autor\">%s",$idRec[ "a" ]);
	        if (!isset($arrPost[ "IdAutor" ]) or $arrPost[ "IdAutor"]=="")
	        {
	        	printf(" - <a href=\"%s?IdAutor=%s\"><img src=\"img/masautor.gif\" title=\"Buscar otros libros de este autor\" alt=\"Buscar otros libros de este autor\"/></a>", $ruta, $idRec[ "IdAutor" ] );
	        }
	        printf("</td>\n");



		  //consulta de ejemplares disponibles y prestados
		  $cSql1 = "SELECT * FROM ejemplares WHERE IdFondo = ".$idRec[ "IdFondo" ];
          $idQry1 = mysql_query( $cSql1, $idCon );
          $nRecuperados1 =  mysql_num_rows( $idQry1 );

             $disponibles=0;
             if( $nRecuperados1 > 0 )
               {
	            while( $idRec1 = mysql_fetch_array( $idQry1 ) ) 
                     {
                     if (!$idRec1[ "Prestado" ])
                        {$disponibles++; }
                     }
                     printf( "<td>%s/%s</td>", $disponibles, $nRecuperados1 );
               }
             else {
                   printf( "<td>%s</td>", "No hay ejemplares" );
                   }
           printf( "</tr>" );
	    }
	}
	else
	{
	    printf( "<tr class=\"busqueda\"><th colspan=\"7\">Búsqueda [ %s ]", $cTexto );
	    printf( "<br/>No hay resultados</th></tr>");
	}
	printf( "</table>" );
	desconectaDb($idCon);

}


function reinicio()
{
	$_SESSION['cSql']="";
	$_SESSION['cTexto']="";
	$_SESSION['pagina']="";
	$_SESSION['orden']="";
	$_SESSION['direc']="";
	unset($_SESSION['cSql']);
	unset($_SESSION['cTexto']);
	unset($_SESSION['pagina']);
	unset($_SESSION['orden']);
	unset($_SESSION['direc']);
	session_destroy();
	header("Location:index.php");
}


?>
<?php
////////////////////////////
//
//	 MyAbies: admin.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
// zona de administracion
//////////////////
ob_start();
session_start();

$titulo_web="MyAbies";
include "content/encabezadocss.php";
////////
//
// Zona de adminstración de MyAbies
// Incluye autentificación,
// que da acceso a la subida del fichero
// con el script generado desde Access
// y a la configuración de los datos de conexion
// que se hace al instalar
//
////////


//////////////////////
//configuración: longitud mínima de las claves de usuario
$long_min=5;


//variable con la ruta a la página
$direcc = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
$ruta = $direcc.$_SERVER['HTTP_HOST']; //ruta a la raiz del servidor NO DE LA PAGINA!!!
$direcc.=$_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
///////////////////////////


// funciones2.php contiene parte de funciones.php + las funciones necesarias para administracion:
// formLogin, cargaScript... 

include_once("includes/funciones2.php"); 
// proceso de logout 
if (isset($_GET['r']))
{
	$_SESSION['usuario']="";
	unset($_SESSION['usuario']);
	echo "<div id=\"caja\"><br/><h3>Sesión cerrada.</h3><br/></div>\n";
	header("Refresh:2;$direcc");
	die();
}

//////////////
// Comprobación ficheros configuracion
//
//
// Se comprueba la existencia de los ficheros adm.php y db.php
// Si no existen, se lanza la gestion de creacion
//
////////

// fichero usuario de administracion
//
// Notar que en este caso no se comprueban datos de usuario,
// antes de permitir la modificación de los datos
//
if (!file_exists("content/data/adm.php"))
{
	gestionAdm();
	die();
}

// fichero datos conexion DB
if (!file_exists("content/data/db.php"))
{
	gestionDb();
	die();
}


/////////////
//
// Pagina de administracion
//
/////////////


if (!isset($_SESSION['usuario'])) //si no tenemos session de usuario
{
	//si no hemos recibido 'u' ni 'ps' por POST, es el primer acceso. Lanzo formulario de acceso y termino
	if (!isset($_POST['u']) AND !isset($_POST['ps']))
	{
		formLogin();
		echo "</body>\n";
		echo "</html>\n";
		die();
	}
	else //ya he recibido valores por el formulario, compruebo el valor con las claves definidas en adm.php, 
	{    //creadas en la instalación mediante el archivo install.php
	
		include_once("content/data/adm.php");
		//primero limpio los parametros recibidos
		$tempU=ioCleanEstricta($_POST['u']);
		$tempP=ioCleanEstricta($_POST['ps']);
		//calculo el hash del valor ps (se usa sha1):
		$tempP=sha1($tempP);
		if ($tempU==$usuario_valido AND $tempP==$clave_valida) //el usuario y la clave coinciden, pongo session y recargo
		{
			echo "<div id=\"caja\"><br/><h3>Accediendo, espere...</h3><br/></div>\n";
			$_SESSION['usuario']=$tempU;
			header("Refresh:2;$direcc");
		}
		else
		{
			echo "<div id=\"wrapper\">";
			echo "<div id=\"page\">";
			echo "Usuario o clave no validos</div></div>";
			header("Refresh:5;$direcc");
		}
		
	}
}
else //ya tenemos session de usuario
{
	include_once("content/data/adm.php");
	//Siempre comprobamos su validez, debe coincidir el valor almacenado con el de la variable usuario
	if ($_SESSION['usuario']==$usuario_valido) //el usuario es correcto, se ha comprobado que lo almacenado en la session es valido
	{
		//primero miro si han solicitado una seccion concreta, o si salgo por defecto (actualizacion)
		if (isset($_GET['c']) OR isset($_GET['d']) OR isset($_GET['e'])) //si es un cambio de clave, datos conexion o enlace externo
		{
			//puede que me hayan pedido cambio de claves o configuración. Lanzo la gestion.
			if (isset($_GET['c'])) //el cambio de clave se recibe con un enlace GET, parametro c
			{
				gestionAdm();
			}
	
			if (isset($_GET['d'])) //el cambio de datos de conexion se recibe con un enlace GET, parametro d
			{
				include_once("content/data/db.php");
				gestionDb();
			}
			
			if (isset($_GET['e']))
			{
				if (file_exists("content/data/enlace.php"))
				{
					include_once("content/data/enlace.php");
				}
				gestionEnlace();
			}
		}
		else //es actualizacion de la bbdd, se toma como valor predeterminado, dado que será lo que se use mas a menudo
		{    //el resto de parametros normalmente no se modificarán.
			//a partir de este punto es necesaria conexion a la BBDD. Primero lanzamos una comprobación, si no se supera, se termina
			include_once("content/data/db.php");
			$conexion = mysql_connect(DB_HOST,DB_USER,DB_PASSWD);
			if (!$conexion)
			{
				echo "<div id=\"wrapper\">";
				echo "<div id=\"page\">";
				echo "No se pudo conectar (¿datos incorrectos?)<br/>";
				die("Por favor, contacte con el administrador (ERROR 003)<br/>" . mysql_error()."</div></div>");
			}
			//Si he llegado hasta aqui, se que:
			// 1.- No es cambio de clave ni de datos DB
			// 2.- Se pudo conectar con la BBDD
			//
			// Ahora puede ser:
			// a.- ya he recibido fichero (lo poceso)
			// b.- no he recibido fichero (muestro el formulario)
	
			
			//si no tengo fichero recibido, y no es solicitud de cambio de clave o conexion
			//mostramos formulario de carga de fichero
			if (!isset($_FILES['file']['tmp_name']))
			{
				formFichero();
			}
			//tengo fichero recibido, lo proceso
			//mediante cargaScript();
			//OJO: en este punto ya se confia en el usuario, no se hace comprobacion de lo que lleva a cabo el script.
			else
			{
				include_once("content/data/db.php");
				cargaScript($_FILES['file']['tmp_name']);
			}
		} //fin gestion de usuario correcto
		
	}
	else //no es el usuario correcto, elimino la session y recargo.
	{
			echo "<div id=\"wrapper\">";
			echo "<div id=\"page\">";
			echo "Error. Vuelva a intentar la conexión.<br/>\n";
			echo "</div></div><br/>\n";
			$_SESSION['usuario']="";
			unset($_SESSION['usuario']);
			header("Refresh:2;$direcc");			
	}
}
echo "</body>\n";
echo "</html>\n";
?>
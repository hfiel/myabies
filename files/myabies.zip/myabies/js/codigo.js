//Hector Fiel - Myabies
function inicial(){
	document.getElementById("logospie").style.display = "none";
	if(document.getElementById("resultados"))
	{
		ocultarheader();
		ocultarform();
	}
	else
	{
		mostrarheader();
		mostrarform();
	}
}
function mostrarform(){
	document.getElementById("formulario").style.display = "block";
	document.getElementById("textonueva").innerHTML = "Nueva B&uacute;squeda</a>";
	document.formbus.autor.focus();
}

function mostrarheader(){
	document.getElementById("header").style.display = "block";
	document.getElementById("textohead").innerHTML = "Consulta al cat&aacute;logo Abies";
}

function ocultarform(){
	document.getElementById("formulario").style.display = "none";
	document.getElementById("textonueva").innerHTML = "<a onclick='javascript:mostrarform();'><span id='textohead'>Mostrar formulario de b&uacute;squeda</span></a>";
}

function ocultarheader(){
	document.getElementById("header").style.display = "none";
	document.getElementById("textohead").innerHTML = "<a onclick='javascript:mostrarheader();'><span id='textohead'>Mostrar la barra superior</span></a>";
}

function mostrarlogospie(){
	document.getElementById("logospie").style.display = "block";
}
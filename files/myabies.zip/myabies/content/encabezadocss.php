<?php
////////////////////////////
//
//	 MyAbies: encabezadocss.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//
////////////////////////////
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es-es">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" /><title>
<?php
	if (isset($titulo_web))
	{
		echo "$titulo_web";
	}
	else
	{
		echo "MyAbies";
	}
?></title>
<link href="css/estilo.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript" src="js/codigo.js"></script>
</head>
<body onload="javascript:inicial();">
<div id="wrapper">

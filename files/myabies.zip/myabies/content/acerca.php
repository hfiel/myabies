<?php
////////////////////////////
//
//	 MyAbies: acerca.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//
////////////////////////////
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es-es">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" /><title>Acerca de MyAbies</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<h2>
		<span style="font-weight: bold;">Acerca de MyAbies</span>
	</h2>
	<h3>MyAbies es un proyecto de software libre realizado por <a href="http://hfiel.es" target="_blank">Héctor Fiel Martín</a>.</h3>
	<p>
	MyAbies permite consultar el catálogo bibliotecario Abies desde un navegador Web, ofreciendo una interfaz sencilla de consulta y administración. Se encuentra implementado sobre PHP y MySQL, y su uso es libre.<br/>
	Puede obtenerse una copia del mismo en <a href="http://myabies.hfiel.es" target="_blank">http://myabies.hfiel.es</a>
	</p> 
	<hr>
	<h2>
		<span style="font-weight: bold;">Reconocimientos</span>	
	</h2>
	<ul>
		<li>
			Mi reconocimiento para <a href="http://www.eduredes.com">Alberto Ruíz</a>, por ser el creador de <a href="http://www.eduredes.com/w/tiki-index.php?page=CatalogoAbiesenMySQL">Abies-web-mysql</a>, proyecto en el que se basa MyAbies.
		</li>
		<li>
			El estilo CSS es una adaptación de la plantilla <a href="http://www.freecsstemplates.org/preview/unembellished">Unembellished</a> de <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.
		</li>
</body>
</html>
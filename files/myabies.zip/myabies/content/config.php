<?php

////////////////////////////
//
//	 MyAbies: config.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//
// Definición de constantes y variables generales
////////////////////////////


//url de la pagina
//antes comprobamos si estamos ante http o https
//$ruta contiene la ruta completa (incluido http)
//$url solo el nombre de la pagina inicial

$ruta = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';

$ruta.=$_SERVER['HTTP_HOST']. $_SERVER['SCRIPT_NAME'];

$url = "index.php";



//nº de registros a mostrar por página:

$cuantos_pag=10;	

//lista de provincias

define( "LST_PROVINCIAS", "A|AB|AL|AV|B|BA|BI|BU|C|CA|CC|CE|CO|CR|CS|CU|GC|GI|GR|GU|H|HU|J|L|LE|LO|LU|M|MA|ML|MU|NA|O|OR|P|PM|PO|S|SA|SE|SG|SO|SS|T|TF|TO|V|VA|VI|Z|ZA" );

?>
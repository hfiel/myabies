<?php
////////////////////////////
//
//	 MyAbies: ayuda2.php (ayuda administración)
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
////////////////////////////

ob_start();
session_start();
	if (!isset($_SESSION['usuario'])) //si no se ha iniciado sesión (desde administracion), terminamos
	{
		die(); //terminamos sin mostrar nada, es una pagina de ayuda que parecera "en blanco";
	}
	else //se ha iniciado sesion, comprobamos su validez
	{
		include_once("data/adm.php"); //cargamos el fichero de acceso de adminstracion
		//debe coincidir el valor almacenado en session con el de la variable usuario definida en el fichero adm.php
		if (!$_SESSION['usuario']==$usuario_valido) //el usuario no es correcto
		{
			die();//terminamos sin mostrar nada.
		}
		else //el usuario es correcto, se ha comprobado que lo almacenado en la session es valido
		{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es-es">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" /><title>MyAbies: Ayuda de administración</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<h2>
		<span style="font-weight: bold;">Ayuda de administración</span>
	</h2>
	Desde la zona de administración puede llevar a cabo las siguientes acciones:
	<ol>
		<li><em>Actualizar MyAbies</em> (pagina predeterminada): para cargar el fichero de script con los datos de Abies (<em>myabiesdump.sql</em>), generado mediante <em>myabies.mdb</em> en el equipo cliente. Si no tiene el fichero, puede descargarlo desde esa misma página.
		</li>
		<li><em>Cambiar claves</em>: permite modificar el nombre de usuario y la contraseña para acceder a la zona de adminstración.
		</li>
		<li><em>Cambiar datos de conexión</em>: para cambiar los datos de acceso a la base de datos MySql.
		</li>
		<li><em>Configurar título</em>: permite definir el título y un enlace externo para mostrar en la página inicial.
		</li>
	</ol>
	Siga los enlaces de la parte inferior para desplazarse por las distintas opciones.
</body>
</html>
<?
		}
	}
?>

<?php
////////////////////////////
//
//	 MyAbies: formulario.php
//
//   Acceso al catálogo OPAC de Abies en MySql
//   a través de navegador de Internet
//
//	 Héctor Fiel Martín, IES Bezmiliana 2009
//
//	formularioAbies -> Muestra el formulario para realizar consultas a la BBDD
//
///////////////////////////////////////////////
function formularioAbies()
{
    global $url;
	
	//
	//	Rellena los tipos de documento
	//
	$cSelectTiposFondo = "";
	$cSql = "SELECT * FROM tiposfondo";
	include_once "conexion.php";
	$idCon=conectaDb();
	if ($idQry = mysql_query( $cSql, $idCon ))
	{
	while( $idRec = mysql_fetch_array( $idQry ) ) 
	    $cSelectTiposFondo .= sprintf( "<option value=\"%s\">%s</option>\n", $idRec[ "TipoFondo" ], $idRec[ "TipoFondo" ] );
	}
	else
	{
		$cSelectTiposFondo .= "<option value=\"\"></option>";
	}
	desconectaDb($idCon);
	//
	//	Rellena las provincias para el código de provincia del D.L.
	//
	$cSelectProvincia = "";
	$aProvincias = explode( "|", LST_PROVINCIAS );
	for( $i = 0; $i < count( $aProvincias ); $i++ )
	    $cSelectProvincia .= sprintf( "<option value=\"%s\">%s</option>\n", $aProvincias[ $i ], $aProvincias[ $i ] );
    
?>
	<p id="nueva"><a onclick="javascript:mostrarform();"><span id="textonueva">Nueva búsqueda</span></a></p>
    <div id="formulario">
	<form action="<? printf( $url ); ?>" method="post" name="formbus">

    <input type="hidden" name="idFondo" value="0" />
	<table border="1" class="formSearch" align="center">
	    <tr>
	        <th colspan="2">Búsqueda de documentos
		    </th>
		        
	    </tr>
		<tr>
	        <td id="isbn" align="center">Código de Barras / ISBN:<br/>
	            <input type="text" name="isbn" value="<? printf( $isbn ); ?>" />
	        </td>
			<td class="cualquier" align="right">Tipo de documento:
	            <select name="tipofondo" >
	                <option value="0" selected="selected">Todos</option>
	                <? printf( $cSelectTiposFondo ); ?>
	            </select>
			</td>
		</tr>
		<tr>
	        <td id="dl">
	            <table>
					<tr>
						<td colspan="3" align="center">Depósito Legal</td>
					</tr>
					<tr>
						<td align="center">Provincia</td>
						<td align="center">Código</td>
						<td align="center">Año</td>
					</tr>
					<tr>
						<td><select name="dl_provincia" >
								<option value="" selected="selected"></option>
								<? printf( $cSelectProvincia ); ?>
							</select>
						</td>
						<td>
							<input type="text" name="dl_codigo" />
						</td>
						<td>
							<input type="text" name="dl_ano" size="4" />
						</td>
					</tr>
				 </table>
	        </td>
			<td class="cualquier">
	            <table>
	                <tr><td align="right">Autor:</td><td><input type="text" name="autor" id="autor" /></td></tr>
	                <tr><td align="right">Título:</td><td><input type="text" name="titulo" /></td></tr>
	                <tr><td align="right">Editorial:</td><td><input type="text" name="editorial" /></td></tr>
	            </table>
			</td>
		</tr>
		<tr>
			<td align="center">Cod. Ejemplar:<input type="text" name="codejemplar"  /></td>
			<td align="right">Signatura<a></a>:<input type="text" size="5" name="signatura1" />
			-
			<input type="text" size="5" name="signatura2" />
			-
			<input type="text" size="5" name="signatura3" /></td>
		</tr>
		<tr>
	        <td colspan="2" align="center">
	            <input type="submit" value="Aceptar" />
	            <input type="reset" value="Cancelar" />
			</td>
		</tr>
	</table>
	</form>
	</div>
	<br/>
	<?
}
?>